allfunc<-function(hiddenstats,seqsize,threshold){
  data=createData()
  data@mu<-c(75,44,64,70,6,89,38,24,75) #Erwartungswerte
  data@sigma<-c(30,15,40,60,5,40,18,15,30)#Standarabweiung 
  data@probality<-c(7.5,8.32,5.91,0.43,1.36,1.87,6.36,0.6,2.46)#Gewichtung der Einkaeufe
  data<-normProbs(data)
  data@intervall=c(0,200)
  clust=Cluster()
  clust@Profil<-data
  clust=iniCluster(clust,2000)
  func(clust,hiddenstats,seqsize,threshold)
}

func<-function(clust,hiddenstats,seqsize,threshold){
  trainIter=2000
  observations=3
  model=Model()
  model=iniModel(model,clust,hiddenstats,observations)
  model=trainModel(model,trainIter)
  dekt=Detektion()
  dekt=iniDetektion(dekt,model,seqsize,threshold)
  ret=rep(0,21)
  for(i in 1:100){
    dekt=addValues(dekt,getValues(model@cluster,seqsize))
    value=getValues(model@cluster,1)
    if(testValue(dekt,value))
      ret[1]=ret[1]+1
  }
  for(s in (1:20)){
    for(i in 1:100){
      dekt=addValues(dekt,getValues(model@cluster,seqsize))
      if(testValue(dekt,s*10))
        ret[1+s]=ret[1+s]+1
    }
  }
  return(ret)
}

