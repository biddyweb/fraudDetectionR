createData <- setClass(
  # Set the name for the class
  "create Data",
  
  # Define the slots
  slots = c(
    mu = "numeric",
    sigma = "numeric"
  ),
  
  # Set the default values for the slots. (optional)
  prototype=list(
    n = 1.0
    ncp = 0.0;
  ),
  
  # Make a function that can test to see if the data is consistent.
  # This is not called if you have an initialize function defined!
  validity=function(object)
  {
    if((object@n < 1) || (object@ncp < 0)) {
      return("Illigale nummer")
    }
    return(TRUE)
  }
)
setMethod(f="getData",
          signature="createData",
          definition=function(theObject,anzahl)
          {
            if(anzahl>=1){
              
              return(rchisq(anzahl, theObject@n, theObject@ncp))
            }
            return("muss mindestens ein wert gefragt werden")
          }
)