library("HMM", lib.loc="D:/Program Files (x86)/R-3.1.1/library")
source('./createData.R')
source('./Cluster.R')
source('./Modell.R')
source('./Detektion.R')

# Mischverteilung von Normalverteilung
data=createData()
data@mu<-c(75,44,64,70,6,89,38,24,75) #Erwartungswerte
data@sigma<-c(30,15,40,60,5,40,18,15,30)#Standarabweiung 
data@probality<-c(7.5,8.32,5.91,0.43,1.36,1.87,6.36,0.6,2.46)#Gewichtung der Einkaeufe
data<-normProbs(data)
data@intervall=c(0,200)
draw(data)#Ausgabe der Daten

# Ini Clusters
clust=Cluster()
clust@Profil<-data
clust=iniCluster(clust,2000)

# Create and train HMM
hiddenstats=3
observations=3
trainIter=200

model=Model()
model=iniModel(model,clust,hiddenstats,observations)
model=trainModel(model,trainIter)

# Ini Detection
dekt=Detektion()
dekt=iniDetektion(dekt,model,5,0.3)

#detect fraud
value=2
testValue(dekt,value)
if(!testValue(dekt,value))
  dekt=addValue(dekt,value)
