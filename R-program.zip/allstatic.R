testingallfunc<-function(){
  data=createData()
  data@mu<-c(75,44,64,70,6,89,38,24,75) #Erwartungswerte
  data@sigma<-c(30,15,40,60,5,40,18,15,30)#Standarabweiung 
  data@probality<-c(7.5,8.32,5.91,0.43,1.36,1.87,6.36,0.6,2.46)#Gewichtung der Einkaeufe
  data<-normProbs(data)
  data@intervall=c(0,200)
  clust=Cluster()
  clust@Profil<-data
  clust=iniCluster(clust,2000)

  trainIter=200
  observations=3
  ret=c()
  for(hiddenstats in 5){#:10){ 
    model=Model()
    model=iniModel(model,clust,hiddenstats,observations)
    model=trainModel(model,trainIter)
    for(seqsize in 5){#1:5 *5){
      for(th in 1:4 *0.2){  
        ret=c(ret,testfunc(model,seqsize,th + 0.1))
      }
    }
  }
  rete=array(ret,dim = c(21,6,6,4))
  return(rete)
}

testfunc<-function(model,seqsize,threshold){
  dekt=Detektion()
  dekt=iniDetektion(dekt,model,seqsize,threshold)
  ret=rep(0,21)
  
  for(i in 1:10){
    dekt=addValues(dekt,getValues(model@cluster@Profil,seqsize))
    value=getValues(model@cluster,1)
    if(testValue(dekt,value))
      ret[1]=ret[1]+1
  }
  
  for(s in (1:20)){
    for(i in 1:10){
      dekt=addValues(dekt,getValues(model@cluster@Profil,seqsize))
      if(testValue(dekt,s*10))
        ret[1+s]=ret[1+s]+1
    }
  }
  return(ret)
}
